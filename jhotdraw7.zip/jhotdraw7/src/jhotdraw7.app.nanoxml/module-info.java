module jhotdraw7.app.nanoxml {
    exports org.jhotdraw.nanoxml;
    exports org.jhotdraw.nanoxml.css;
    requires jhotdraw7.app;
    requires nanoxml;
    requires jsr305;
}