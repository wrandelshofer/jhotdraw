module jhotdraw7.samples.teddy {
    requires java.desktop;
    requires java.prefs;
    requires jsr305;
    requires jhotdraw7.app;
}