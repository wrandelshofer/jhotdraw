module jhotdraw7.samples.odg {
    requires java.desktop;
    requires jhotdraw7.draw;
    requires jhotdraw7.app;
    requires jsr305;
    requires java.prefs;
    requires nanoxml;
    requires jhotdraw7.app.nanoxml;
    requires jhotdraw7.samples.svg;
}