/* @(#)ODGFigureFactory.java
 * Copyright © 1996-2017 The authors and contributors of JHotDraw.
 * MIT License, CC-by License, or LGPL License.
 */

package org.jhotdraw.samples.odg.io;

/**
 * ODGFigureFactory.
 *
 * @author Werner Randelshofer
 * @version $Id$
 */
public interface ODGFigureFactory {
    
    
}
