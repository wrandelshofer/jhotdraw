module jhotdraw7.samples.svg {
    exports org.jhotdraw.samples.svg;
    exports org.jhotdraw.samples.svg.action;
    exports org.jhotdraw.samples.svg.figures;
    exports org.jhotdraw.samples.svg.io;
    requires java.desktop;
    requires jhotdraw7.draw;
    requires jhotdraw7.app;
    requires jsr305;
    requires java.prefs;
    requires nanoxml;
    requires jhotdraw7.app.nanoxml;
}