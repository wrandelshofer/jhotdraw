module jhotdraw7.samples.draw {
    requires jsr305;
    requires java.desktop;
    requires jhotdraw7.app.nanoxml;
    requires jhotdraw7.app;
    requires jhotdraw7.draw;
}