module jhotdraw7.samples.pert {
    requires jhotdraw7.app;
    requires java.desktop;
    requires jhotdraw7.draw;
    requires java.prefs;
    requires jsr305;
    requires jhotdraw7.app.nanoxml;
}